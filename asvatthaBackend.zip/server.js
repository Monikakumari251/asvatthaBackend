const express = require("express");
const bodyParser = require("body-parser");
// let cors = require('cors')
const cors = require('cors');




const app = express();
const corsOptions ={
  origin:'http://localhost:3001', 
  credentials:true,            //access-control-allow-credentials:true
  optionSuccessStatus:200
}
app.use(cors(corsOptions));

// parse requests of content-type: application/json
app.use(bodyParser.json());
// app.use(cors(bodyParser.json()))

// parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// app.use(cors(bodyParser.urlencoded({ extended: true })));

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to bezkoder application." });
});

require("./app/routes/volunteer.routes")(app);
// set port, listen for requests
app.listen(3000, () => {
  console.log("Server is running on port 3000.");
});
