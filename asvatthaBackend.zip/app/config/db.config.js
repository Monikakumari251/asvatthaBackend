module.exports = {
    HOST: "65.1.117.122",
    USER: "dbadmin",
    PASSWORD: "Pass123$",
    DB: "asvattha"
  };